'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const core = require('../public/nakliye-bekleyen-core.js');

test('parsePendingNote detects full and partial plaka messages', () => {
  assert.deepEqual(core.parsePendingNote('PLAKA VERİLECEK'), {
    remainingBbt: null,
    text: 'PLAKA VERİLECEK',
  });
  assert.deepEqual(core.parsePendingNote('92BBT PLAKA VERİLECEK'), {
    remainingBbt: 92,
    text: '92BBT PLAKA VERİLECEK',
  });
});

test('isRowDeparted uses giden tonaj', () => {
  assert.equal(core.isRowDeparted({ gidenTonaj: '5.000' }), true);
  assert.equal(core.isRowDeparted({ gidenTonaj: '' }), false);
  assert.equal(core.isRowDeparted({ gidenTonaj: '0' }), false);
});

test('analyzeBlock — no plate, plan from header', () => {
  const item = core.analyzeBlock([
    { blockKey: 'X', blockHeaderRow: 10, headerText: 'YD235 / 20 BBT', ydKey: 'YD235', _ihracatEmptyBlock: true },
  ]);
  assert.ok(item);
  assert.equal(item.planBbt, 20);
  assert.equal(item.remainingBbt, 20);
  assert.equal(item.waitingPlates.length, 0);
});

test('analyzeBlock — departed truck is hidden', () => {
  const item = core.analyzeBlock([
    { blockKey: 'Z', blockHeaderRow: 5, headerText: 'YD265 / 40 BBT', plaka: '03EA682', bbt: '20', gidenTonaj: '20' },
    { blockKey: 'Z', blockHeaderRow: 5, headerText: 'YD265 / 40 BBT', plaka: '03EA029', bbt: '20', gidenTonaj: '20' },
  ]);
  assert.equal(item, null);
});

test('analyzeBlock — waiting plate without giden tonaj', () => {
  const item = core.analyzeBlock([
    {
      blockKey: 'W',
      blockHeaderRow: 8,
      headerText: 'YD82 / 4 BBT',
      plaka: '64BE703',
      bbt: '4',
      gidenTonaj: '',
    },
  ]);
  assert.ok(item);
  assert.equal(item.waitingPlates.length, 1);
  assert.equal(item.waitingPlates[0].plaka, '64BE703');
  assert.equal(item.remainingBbt, 0);
});

test('analyzeBlock — partial: waiting plate + remaining BBT', () => {
  const item = core.analyzeBlock([
    { blockKey: 'Y', blockHeaderRow: 20, headerText: 'YD03 / 120 BBT', plaka: '03VY230', bbt: '28', gidenTonaj: '' },
    {
      blockKey: 'Y',
      blockPendingPlakaNotes: [{ text: '92BBT PLAKA VERİLECEK', remainingBbt: 92 }],
    },
  ]);
  assert.ok(item);
  assert.equal(item.remainingBbt, 92);
  assert.equal(item.waitingPlates.length, 1);
});

test('buildExcelBlockRows — plaka yanında gelmeyen araç', () => {
  const item = core.analyzeBlock([
    {
      blockKey: 'Y',
      headerText: 'YD03 / 120 BBT / HP 1,20-2,40',
      plaka: '03VY230',
      bbt: '28',
      gidenTonaj: '',
    },
    { blockKey: 'Y', blockPendingPlakaNotes: [{ text: '92BBT PLAKA VERİLECEK', remainingBbt: 92 }] },
  ]);
  const rows = core.buildExcelBlockRows(item);
  assert.equal(rows[0].a, 'YD03 120 BBT (HP 1,20-2,40)');
  assert.equal(rows[1].a, '03VY230');
  assert.equal(rows[1].b, 'GELMEYEN ARAÇ');
  assert.equal(rows[1].c, '28 BBT');
  assert.equal(rows[1].kind, 'plate');
  assert.equal(rows[2].a, '92 BBT DAHA PLAKA VERİLECEK');
  assert.equal(rows[2].kind, 'pending');
  assert.equal(rows.length, 3);
  const sheetRows = core.buildExcelSheetRows([item]);
  assert.equal(sheetRows[sheetRows.length - 1].a, '92 BBT DAHA PLAKA VERİLECEK');
  assert.equal(sheetRows[sheetRows.length - 1].kind, 'pending');
});

test('buildExcelSheetRows — each block shows its own remaining BBT', () => {
  const rows = core.buildExcelSheetRows([
    core.analyzeBlock([
      {
        blockKey: 'Y',
        headerText: 'YD03 / 120 BBT',
        plaka: '03VY230',
        bbt: '28',
        gidenTonaj: '',
      },
      { blockKey: 'Y', blockPendingPlakaNotes: [{ text: '92BBT PLAKA VERİLECEK', remainingBbt: 92 }] },
    ]),
    core.analyzeBlock([
      {
        blockKey: 'Z',
        headerText: 'YD05 / 88 BBT',
        _ihracatEmptyBlock: true,
      },
    ]),
  ]);
  const pending = rows.filter((r) => r.kind === 'pending');
  assert.deepEqual(pending.map((r) => r.a), ['92 BBT DAHA PLAKA VERİLECEK', '88 BBT DAHA PLAKA VERİLECEK']);
});

test('buildExcelBlockRows — gelmeyen plakalar + hesaplanan kalan BBT', () => {
  const item = core.analyzeBlock([
    {
      blockKey: 'Y',
      headerText: 'YD05 / 800 BBT / HP 0,074-0,30',
      plaka: '43VE530',
      bbt: '22',
      gidenTonaj: '',
    },
    {
      blockKey: 'Y',
      headerText: 'YD05 / 800 BBT / HP 0,074-0,30',
      plaka: '06ABC123',
      bbt: '26',
      gidenTonaj: '',
    },
  ]);
  assert.equal(item.remainingBbt, 752);
  const rows = core.buildExcelBlockRows(item);
  assert.equal(rows[rows.length - 1].a, '752 BBT DAHA PLAKA VERİLECEK');
  assert.equal(rows[rows.length - 1].kind, 'pending');
});

test('buildExcelSheetRows — plate numbers use Excel sira', () => {
  const rows = core.buildExcelSheetRows([
    core.analyzeBlock([
      {
        blockKey: 'Y',
        headerText: 'YD03 / 32 BBT',
        plaka: '03VY230',
        sira: '12',
        bbt: '28',
        gidenTonaj: '',
      },
    ]),
    core.analyzeBlock([
      {
        blockKey: 'Z',
        headerText: 'YD05 / 4 BBT',
        plaka: '06ABC123',
        sira: '18',
        bbt: '4',
        gidenTonaj: '',
      },
    ]),
  ]);
  const plates = rows.filter((r) => r.kind === 'plate');
  assert.equal(plates.length, 2);
  assert.equal(plates[0].no, 12);
  assert.equal(plates[1].no, 18);
  assert.ok(!rows.some((r) => r.kind === 'waiting-total'));
});

test('printReportValidForMeta accepts same-day print after excel re-import', () => {
  const meta = {
    importedAt: '2026-07-15T14:00:00.000Z',
    dateKey: '2026-07-15',
  };
  const morningPrint = new Date('2026-07-15T07:00:00.000Z').getTime();
  assert.equal(core.printReportValidForMeta(morningPrint, meta), true);
});

test('applyLiveDepartedMarks — print report marks row departed', () => {
  const meta = { importedAt: '2026-07-15T08:00:00.000Z' };
  const rows = [
    {
      blockKey: 'B1',
      headerText: 'YD82 / 4 BBT',
      ydKey: 'YD82',
      plaka: '64BE703',
      bbt: '4',
      gidenTonaj: '',
    },
  ];
  const reports = [
    {
      type: 'PRINT',
      ts: new Date('2026-07-15T10:00:00.000Z').getTime(),
      data: { plaka: '64BE703', firma: 'YD82' },
    },
  ];
  const out = core.applyLiveDepartedMarks(rows, meta, reports);
  assert.ok(core.isRowDeparted(out[0]));
  assert.equal(core.analyzeBlock(out), null);
});

test('applyLiveDepartedMarks — çift kantar consumes one row at a time', () => {
  const meta = { importedAt: '2026-07-15T08:00:00.000Z' };
  const rows = [
    { blockKey: 'B1', headerText: 'YD82 / 4 BBT', ydKey: 'YD82', plaka: '64BE703', bbt: '4', gidenTonaj: '' },
    { blockKey: 'B2', headerText: 'YD82 / 16 BBT', ydKey: 'YD82', plaka: '64BE703', bbt: '16', gidenTonaj: '' },
  ];
  const reports = [
    {
      type: 'PRINT',
      ts: new Date('2026-07-15T10:00:00.000Z').getTime(),
      data: { plaka: '64BE703', firma: 'YD82' },
    },
  ];
  const out = core.applyLiveDepartedMarks(rows, meta, reports);
  assert.ok(core.isRowDeparted(out[0]));
  assert.equal(core.isRowDeparted(out[1]), false);
  const pending = core.analyzeNakliyePending(out);
  assert.equal(pending.length, 1);
  assert.equal(pending[0].planBbt, 16);
});

test('applyLiveDepartedMarks — other YD print does not hide gelmeyen plate', () => {
  const meta = { importedAt: '2026-08-18T08:00:00.000Z' };
  const rows = [
    {
      blockKey: 'YD40',
      headerText: 'YD40(G) / 200 BBT',
      ydKey: 'YD40',
      plaka: '03DH540',
      bbt: '24',
      gidenTonaj: '',
    },
  ];
  const reports = [
    {
      type: 'PRINT',
      ts: new Date('2026-08-18T10:00:00.000Z').getTime(),
      data: { plaka: '03DH540', firma: 'YD173(G) / LOT NO 26 07 41' },
    },
  ];
  const out = core.applyLiveDepartedMarks(rows, meta, reports);
  assert.equal(core.isRowDeparted(out[0]), false);
  const pending = core.analyzeNakliyePending(out);
  assert.equal(pending.length, 1);
  assert.equal(pending[0].waitingPlates[0].plaka, '03DH540');
});

test('applyLiveDepartedMarks — print without YD does not hide ihracat gelmeyen', () => {
  const meta = { importedAt: '2026-08-18T08:00:00.000Z' };
  const rows = [
    {
      blockKey: 'YD385',
      headerText: 'YD385(M) / 120 BBT',
      ydKey: 'YD385',
      plaka: '43SE883',
      bbt: '22',
      gidenTonaj: '',
    },
  ];
  const reports = [
    {
      type: 'PRINT',
      ts: new Date('2026-08-18T10:00:00.000Z').getTime(),
      data: { plaka: '43SE883' },
    },
  ];
  const out = core.applyLiveDepartedMarks(rows, meta, reports);
  assert.equal(core.isRowDeparted(out[0]), false);
});

test('clearLiveDepartedMark restores Excel GELMEDİ plate that was print-marked', () => {
  const cleaned = core.clearLiveDepartedMark({
    blockKey: 'YD385',
    headerText: 'YD385(M) / 120 BBT',
    plaka: '43SE883',
    bbt: '22',
    gidenTonaj: '22',
    _nbLiveDeparted: true,
  });
  assert.equal(core.isRowDeparted(cleaned), false);
  assert.equal(cleaned.gidenTonaj, '');
  const pending = core.analyzeNakliyePending([
    {
      blockKey: 'YD385',
      blockHeaderRow: 10,
      headerText: 'YD385(M) / 120 BBT',
      plaka: '43ADB640',
      bbt: '22',
      gidenTonaj: '27740',
    },
    Object.assign({ blockHeaderRow: 10 }, cleaned),
  ]);
  assert.equal(pending[0].waitingPlates.map((p) => p.plaka).join(','), '43SE883');
});

test('applyLiveDepartedMarks — same YD print still hides plate', () => {
  const meta = { importedAt: '2026-08-18T08:00:00.000Z' };
  const rows = [
    {
      blockKey: 'YD40',
      headerText: 'YD40(G) / 200 BBT',
      ydKey: 'YD40',
      plaka: '03DH540',
      bbt: '24',
      gidenTonaj: '',
    },
  ];
  const reports = [
    {
      type: 'PRINT',
      ts: new Date('2026-08-18T10:00:00.000Z').getTime(),
      data: { plaka: '03DH540', firmaKodu: 'YD40(G) / LOT NO 26 08 08' },
    },
  ];
  const out = core.applyLiveDepartedMarks(rows, meta, reports);
  assert.ok(core.isRowDeparted(out[0]));
});

test('applyLiveDepartedMarks — strips persisted live mark then re-applies by YD', () => {
  const meta = { importedAt: '2026-08-18T08:00:00.000Z' };
  const rows = [
    {
      blockKey: 'YD385',
      headerText: 'YD385(M) / 120 BBT',
      ydKey: 'YD385',
      plaka: '43SE883',
      bbt: '22',
      gidenTonaj: '22',
      _nbLiveDeparted: true,
    },
  ];
  const reports = [
    {
      type: 'PRINT',
      ts: new Date('2026-08-18T10:00:00.000Z').getTime(),
      data: { plaka: '43SE883', firma: 'YD173' },
    },
  ];
  const out = core.applyLiveDepartedMarks(rows, meta, reports);
  assert.equal(core.isRowDeparted(out[0]), false);
  assert.equal(out[0]._nbLiveDeparted, undefined);
});

test('analyzeNakliyePending — YD385 gelmeyen plates stay visible when remaining is 0', () => {
  const pending = core.analyzeNakliyePending([
    {
      blockKey: 'BLK_10',
      blockHeaderRow: 10,
      headerText: 'YD385(M) / LOT NO 26 07 24 / 120 BBT',
      ydKey: 'YD385',
      plaka: '43ADB640',
      bbt: '22',
      gidenTonaj: '27740',
    },
    {
      blockKey: 'BLK_10',
      blockHeaderRow: 10,
      headerText: 'YD385(M) / LOT NO 26 07 24 / 120 BBT',
      ydKey: 'YD385',
      plaka: '43SE883',
      bbt: '22',
      gidenTonaj: '',
    },
    {
      blockKey: 'BLK_10',
      blockHeaderRow: 10,
      headerText: 'YD385(M) / LOT NO 26 07 24 / 120 BBT',
      ydKey: 'YD385',
      plaka: '43AAZ480',
      bbt: '26',
      gidenTonaj: '',
    },
    {
      blockKey: 'BLK_10',
      blockHeaderRow: 10,
      headerText: 'YD385(M) / LOT NO 26 07 24 / 120 BBT',
      ydKey: 'YD385',
      plaka: '43ABR539',
      bbt: '26',
      gidenTonaj: '',
    },
    {
      blockKey: 'BLK_10',
      blockHeaderRow: 10,
      headerText: 'YD385(M) / LOT NO 26 07 24 / 120 BBT',
      ydKey: 'YD385',
      plaka: '43AK877',
      bbt: '24',
      gidenTonaj: '',
    },
  ]);
  assert.equal(pending.length, 1);
  assert.match(String(pending[0].ydKey), /^YD385/);
  assert.equal(pending[0].remainingBbt, 0);
  assert.equal(pending[0].waitingPlates.length, 4);
  assert.equal(core.hasNakliyeBlockContent(pending[0]), true);
});

test('analyzeNakliyePending — YD40 lists all gelmeyen plates and remaining 27 BBT', () => {
  const pending = core.analyzeNakliyePending([
    { blockKey: 'BLK_36', blockHeaderRow: 36, headerText: 'YD40(G) / 200 BBT', plaka: '03AIT034', sira: '1', bbt: '26', gidenTonaj: '' },
    { blockKey: 'BLK_36', blockHeaderRow: 36, headerText: 'YD40(G) / 200 BBT', plaka: '03ADB390', sira: '2', bbt: '26', gidenTonaj: '' },
    { blockKey: 'BLK_36', blockHeaderRow: 36, headerText: 'YD40(G) / 200 BBT', plaka: '41BFL699', sira: '3', bbt: '21', gidenTonaj: '' },
    { blockKey: 'BLK_36', blockHeaderRow: 36, headerText: 'YD40(G) / 200 BBT', plaka: '03DH540', sira: '4', bbt: '24', gidenTonaj: '' },
    { blockKey: 'BLK_36', blockHeaderRow: 36, headerText: 'YD40(G) / 200 BBT', plaka: '03BN929', sira: '5', bbt: '24', gidenTonaj: '' },
    { blockKey: 'BLK_36', blockHeaderRow: 36, headerText: 'YD40(G) / 200 BBT', plaka: '03VR929', sira: '6', bbt: '24', gidenTonaj: '' },
    { blockKey: 'BLK_36', blockHeaderRow: 36, headerText: 'YD40(G) / 200 BBT', plaka: '16RCU18', sira: '7', bbt: '28', gidenTonaj: '' },
  ]);
  assert.equal(pending.length, 1);
  assert.equal(pending[0].waitingPlates.length, 7);
  assert.equal(pending[0].remainingBbt, 27);
  const sheet = core.buildExcelBlockRows(pending[0]).filter((r) => r.kind === 'plate');
  assert.deepEqual(
    sheet.map((r) => r.a),
    ['03AIT034', '03ADB390', '41BFL699', '03DH540', '03BN929', '03VR929', '16RCU18']
  );
});

test('shouldUseDualColumnLayout — long list uses two columns', () => {
  const bodyRows = [{ kind: 'header' }];
  for (let i = 0; i < 10; i++) bodyRows.push({ kind: 'plate', no: i + 1 });
  bodyRows.push({ kind: 'header' });
  for (let i = 0; i < 4; i++) bodyRows.push({ kind: 'plate', no: 11 + i });
  const blocks = core.groupSheetRowsByBlock(bodyRows);
  assert.equal(blocks.length, 2);
  assert.equal(core.shouldUseDualColumnLayout(bodyRows, blocks), true);
  const cols = core.splitBlocksIntoColumns(blocks);
  assert.equal(cols.length, 2);
  assert.ok(cols[0].length >= 1);
  assert.ok(cols[1].length >= 1);
});

test('shouldUseDualColumnLayout — short list stays single', () => {
  const bodyRows = [{ kind: 'header' }, { kind: 'plate', no: 1 }];
  const blocks = core.groupSheetRowsByBlock(bodyRows);
  assert.equal(core.shouldUseDualColumnLayout(bodyRows, blocks), false);
});

test('buildExcelBlockRows — empty block has header only', () => {
  const item = core.analyzeBlock([
    {
      blockKey: 'X',
      headerText: 'YD82(M) / HP 0,60-1,20 / 4 BBT',
      _ihracatEmptyBlock: true,
    },
  ]);
  const rows = core.buildExcelBlockRows(item);
  assert.equal(rows[0].a, 'YD82(M) 4 BBT (HP 0,60-1,20)');
  assert.equal(rows[1].a, '4 BBT DAHA PLAKA VERİLECEK');
  assert.equal(rows.length, 2);
  const sheetRows = core.buildExcelSheetRows([item]);
  assert.equal(sheetRows[sheetRows.length - 1].a, '4 BBT DAHA PLAKA VERİLECEK');
});

test('multiple YD82 blocks get different malzeme in header', () => {
  const rows = [
    { blockKey: 'B1', blockHeaderRow: 10, headerText: 'YD82(M) / HP 0,60-1,20 / 4 BBT', _ihracatEmptyBlock: true },
    { blockKey: 'B2', blockHeaderRow: 50, headerText: 'YD82(M) / HP 1,20-2,40 / 16 BBT', _ihracatEmptyBlock: true },
    { blockKey: 'B3', blockHeaderRow: 90, headerText: 'YD82(M) / HP 1,20-2,80 / 20 BBT', _ihracatEmptyBlock: true },
  ];
  const pending = core.analyzeNakliyePending(rows);
  assert.equal(pending.length, 3);
  assert.equal(pending[0].malzemeLabel, 'HP 0,60-1,20');
  assert.equal(pending[1].malzemeLabel, 'HP 1,20-2,40');
  assert.equal(pending[2].malzemeLabel, 'HP 1,20-2,80');
});

test('analyzeNakliyePending sorts by Excel blockHeaderRow', () => {
  const rows = [
    { blockKey: 'C', blockHeaderRow: 300, headerText: 'YD99 / 10 BBT', _ihracatEmptyBlock: true },
    { blockKey: 'A', blockHeaderRow: 100, headerText: 'YD82 / 4 BBT', _ihracatEmptyBlock: true },
    { blockKey: 'B', blockHeaderRow: 200, headerText: 'YD03 / 120 BBT', plaka: '03VY230', bbt: '28', gidenTonaj: '' },
    {
      blockKey: 'B',
      blockHeaderRow: 200,
      blockPendingPlakaNotes: [{ text: '92BBT PLAKA VERİLECEK', remainingBbt: 92 }],
    },
  ];
  const pending = core.analyzeNakliyePending(rows);
  assert.deepEqual(pending.map((p) => p.ydKey), ['YD82', 'YD03', 'YD99']);
});

test('çift kantar — same plate in two blocks stays pending in both', () => {
  const rows = [
    { blockKey: 'B1', blockHeaderRow: 10, headerText: 'YD82 / 4 BBT HP0', plaka: '64BE703', bbt: '4', gidenTonaj: '' },
    { blockKey: 'B2', blockHeaderRow: 50, headerText: 'YD82 / 16 BBT HP1', plaka: '64BE703', bbt: '16', gidenTonaj: '' },
  ];
  const pending = core.analyzeNakliyePending(rows);
  assert.equal(pending.length, 2);
  assert.ok(pending.every((p) => p.waitingPlates.some((w) => w.plaka === '64BE703')));
});

test('departed in one block does not hide plate in another block', () => {
  const rows = [
    { blockKey: 'B1', blockHeaderRow: 10, headerText: 'YD82 / 4 BBT', plaka: '64BE703', bbt: '4', gidenTonaj: '4' },
    { blockKey: 'B2', blockHeaderRow: 50, headerText: 'YD82 / 16 BBT', plaka: '64BE703', bbt: '16', gidenTonaj: '' },
  ];
  const pending = core.analyzeNakliyePending(rows);
  assert.equal(pending.length, 1);
  assert.equal(pending[0].planBbt, 16);
  assert.equal(pending[0].waitingPlates[0].plaka, '64BE703');
});

test('isOzmalPlate recognizes company plates with spaces', () => {
  assert.equal(core.isOzmalPlate('43 ADT 557'), true);
  assert.equal(core.isOzmalPlate('43ADT557'), true);
  assert.equal(core.isOzmalPlate('43 ADS 403'), true);
  assert.equal(core.isOzmalPlate('43VE530'), false);
});

test('analyzeBlock — özmal plate separated from gelmeyen list', () => {
  const item = core.analyzeBlock([
    {
      blockKey: 'Y',
      blockHeaderRow: 20,
      headerText: 'YD05 / 800 BBT / HP 0,074-0,30',
      plaka: '43 ADT 557',
      bbt: '24',
      gidenTonaj: '',
    },
    {
      blockKey: 'Y',
      blockHeaderRow: 20,
      headerText: 'YD05 / 800 BBT / HP 0,074-0,30',
      plaka: '43VE530',
      bbt: '22',
      gidenTonaj: '',
    },
  ]);
  assert.equal(item.ozmalPlates.length, 1);
  assert.equal(item.waitingPlates.length, 1);
  assert.equal(item.remainingBbt, 754);
});

test('buildExcelSheetParts — özmal plates are hidden from nakliyeci sheet', () => {
  const item = core.analyzeBlock([
    {
      blockKey: 'Y',
      blockHeaderRow: 20,
      headerText: 'YD05 / 800 BBT',
      plaka: '43 ADT 550',
      bbt: '24',
      gidenTonaj: '',
    },
    {
      blockKey: 'Y',
      blockHeaderRow: 20,
      headerText: 'YD05 / 800 BBT',
      plaka: '43VE530',
      bbt: '22',
      gidenTonaj: '',
    },
  ]);
  assert.equal(item.ozmalPlates.length, 1);
  assert.equal(item.waitingPlates.length, 1);
  const parts = core.buildExcelSheetParts([item]);
  assert.equal(parts.ozmalRows.length, 0);
  const ozmalRow = parts.nakliyeRows.find((r) => r.a === '43ADT550');
  assert.equal(ozmalRow, undefined);
  const waitingRow = parts.nakliyeRows.find((r) => r.a === '43VE530');
  assert.ok(waitingRow);
  assert.equal(waitingRow.b, 'GELMEYEN ARAÇ');
  assert.equal(waitingRow.ozmal, false);
});

test('buildExcelBlockRows — LOT no appears in yellow header per product', () => {
  const item = core.analyzeBlock([
    {
      blockKey: 'L1',
      headerText: 'YD331 / 120 BBT / LOT NO 26 07 20 / HP 0,74-0,40',
      plaka: '43AGK142',
      bbt: '28',
      gidenTonaj: '',
    },
  ]);
  assert.equal(item.lotLabel, 'LOT 26 07 20');
  const rows = core.buildExcelBlockRows(item);
  assert.equal(rows[0].kind, 'header');
  assert.equal(rows[0].a, 'YD331 120 BBT · LOT 26 07 20 (HP 0,74-0,40)');
  assert.equal(rows[0].lotLabel, 'LOT 26 07 20');
});

test('buildBlockPlateRows — sorts by Excel sira within block', () => {
  const item = core.analyzeBlock([
    {
      blockKey: 'Y',
      headerText: 'YD20 / 360 BBT',
      plaka: '03DH540',
      sira: '20',
      bbt: '26',
      gidenTonaj: '',
    },
    {
      blockKey: 'Y',
      headerText: 'YD20 / 360 BBT',
      plaka: '43AGK142',
      sira: '18',
      bbt: '20',
      gidenTonaj: '',
    },
    {
      blockKey: 'Y',
      headerText: 'YD20 / 360 BBT',
      plaka: '20ANA257',
      sira: '19',
      bbt: '20',
      gidenTonaj: '',
    },
  ]);
  const rows = core.buildExcelBlockRows(item).filter((r) => r.kind === 'plate');
  assert.deepEqual(
    rows.map((r) => r.no),
    [18, 19, 20]
  );
  assert.deepEqual(
    rows.map((r) => r.a),
    ['43AGK142', '20ANA257', '03DH540']
  );
});

test('analyzeNakliyePending — same blockKey from different Excel files stay separate', () => {
  const rows = [
    {
      blockKey: 'BLK_20',
      blockHeaderRow: 20,
      headerText: 'YD05 / 800 BBT / HP 0,074-0,30',
      fileName: 'İHRACAT 13.07.2026.xlsx',
      plaka: '43VE530',
      bbt: '22',
      gidenTonaj: '',
    },
    {
      blockKey: 'BLK_20',
      blockHeaderRow: 20,
      headerText: 'YD05 / 400 BBT / HP 0,074-0,30',
      fileName: 'İHRACAT 14.07.2026.xlsx',
      plaka: '03DH540',
      bbt: '24',
      gidenTonaj: '',
    },
  ];
  const pending = core.analyzeNakliyePending(rows);
  assert.equal(pending.length, 2);
  assert.equal(pending[0].planBbt, 800);
  assert.equal(pending[1].planBbt, 400);
  assert.equal(pending[0].sourceDateLabel, '13.07.2026');
  assert.equal(pending[1].sourceDateLabel, '14.07.2026');
});

test('buildExcelSheetParts — multi Excel dates appear in block headers', () => {
  const pending = core.analyzeNakliyePending([
    {
      blockKey: 'BLK_20',
      blockHeaderRow: 20,
      headerText: 'YD05 / 800 BBT',
      fileName: 'İHRACAT 13.07.2026.xlsx',
      plaka: '43VE530',
      bbt: '22',
      gidenTonaj: '',
    },
    {
      blockKey: 'BLK_20',
      blockHeaderRow: 20,
      headerText: 'YD05 / 400 BBT',
      fileName: 'İHRACAT 14.07.2026.xlsx',
      plaka: '03DH540',
      bbt: '24',
      gidenTonaj: '',
    },
  ]);
  const parts = core.buildExcelSheetParts(pending);
  const headers = parts.nakliyeRows.filter((r) => r.kind === 'header').map((r) => r.a);
  assert.equal(headers.length, 2);
  assert.match(headers[0], /13\.07\.2026/);
  assert.match(headers[1], /14\.07\.2026/);
  assert.equal(parts.multiFile, true);
});

test('buildExcelSheetParts — multi Excel without date uses file name in block header', () => {
  const pending = core.analyzeNakliyePending([
    {
      blockKey: 'BLK_5',
      blockHeaderRow: 5,
      headerText: 'YD331 / 120 BBT / HP 0,074-0,40',
      fileName: '20.07.2026.xlsx',
      _ihracatEmptyBlock: true,
      plaka: '',
    },
    {
      blockKey: 'BLK_20',
      blockHeaderRow: 20,
      headerText: 'YD113 / 100 BBT / HP 1,20-2,80',
      fileName: '20.07.2026.xlsx',
      plaka: '03AIT034',
      bbt: '25',
      gidenTonaj: '',
    },
    {
      blockKey: 'BLK_20',
      blockHeaderRow: 20,
      headerText: 'YD33 / 2444 BBT / HP 0,074-0,30',
      fileName: 'YD33 (1).xlsx',
      plaka: '03VT423',
      bbt: '22',
      gidenTonaj: '',
    },
  ]);
  const parts = core.buildExcelSheetParts(pending);
  const headers = parts.nakliyeRows.filter((r) => r.kind === 'header').map((r) => r.a);
  assert.equal(headers.length, 3);
  assert.match(headers[0], /20\.07\.2026 · YD331/);
  assert.match(headers[1], /20\.07\.2026 · YD113/);
  assert.match(headers[2], /YD33 \(1\) · YD33/);
});

test('groupItemsByExcelFile — same file blocks stay in one group', () => {
  const items = [
    { fileName: '20.07.2026.xlsx', blockHeaderRow: 5, ydKey: 'YD331' },
    { fileName: '20.07.2026.xlsx', blockHeaderRow: 20, ydKey: 'YD113' },
    { fileName: 'YD33 (1).xlsx', blockHeaderRow: 10, ydKey: 'YD33' },
  ];
  const groups = core.groupItemsByExcelFile(items);
  assert.equal(groups.length, 2);
  assert.equal(groups[0].length, 2);
  assert.equal(groups[1].length, 1);
  assert.equal(groups[0][0].ydKey, 'YD331');
  assert.equal(groups[0][1].ydKey, 'YD113');
  assert.equal(groups[1][0].ydKey, 'YD33');
});

test('flattenSheetBlocks — stacked blocks in one Excel column', () => {
  const blockA = [
    { kind: 'header', a: 'YD331' },
    { kind: 'pending', a: '120 BBT DAHA PLAKA VERİLECEK' },
  ];
  const blockB = [{ kind: 'header', a: 'YD113' }, { kind: 'plate', a: '03AIT034' }];
  const rows = core.flattenSheetBlocks([[blockA, blockB]]);
  assert.equal(rows.length, 4);
  assert.equal(rows[0].a, 'YD331');
  assert.equal(rows[2].a, 'YD113');
});

test('shouldUseSideBySideFiles — true only for multiple Excel files', () => {
  assert.equal(
    core.shouldUseSideBySideFiles([
      { fileName: 'a.xlsx' },
      { fileName: 'b.xlsx' },
    ]),
    true
  );
  assert.equal(
    core.shouldUseSideBySideFiles([
      { fileName: 'a.xlsx' },
      { fileName: 'a.xlsx' },
    ]),
    false
  );
});

test('buildExcelBlockRows — özmal / başşoför plates are not listed on sheet', () => {
  const item = core.analyzeBlock([
    {
      blockKey: 'Y',
      blockHeaderRow: 20,
      headerText: 'YD05 / 800 BBT',
      plaka: '43 ADS 408',
      bbt: '24',
      gidenTonaj: '',
    },
  ]);
  assert.equal(item.ozmalPlates.length, 1);
  assert.equal(item.waitingPlates.length, 0);
  const rows = core.buildExcelBlockRows(item);
  const ozmalRow = rows.find((r) => r.a === '43ADS408');
  assert.equal(ozmalRow, undefined);
  // Özmal BBT plana sayıldığı için kalan düşer; listede plaka yok
  assert.equal(item.remainingBbt, 776);
});
